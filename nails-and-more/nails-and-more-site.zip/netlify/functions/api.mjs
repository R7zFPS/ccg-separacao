// ../../../../../home/user/ccg-separacao/nails-and-more/node_modules/@netlify/runtime-utils/dist/main.js
var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));
var getEnvironment = () => {
  const { Deno, Netlify: Netlify2, process } = globalThis;
  return Netlify2?.env ?? Deno?.env ?? {
    delete: (key) => delete process?.env[key],
    get: (key) => process?.env[key],
    has: (key) => Boolean(process?.env[key]),
    set: (key, value) => {
      if (process?.env) {
        process.env[key] = value;
      }
    },
    toObject: () => process?.env ?? {}
  };
};

// ../../../../../home/user/ccg-separacao/nails-and-more/node_modules/@netlify/otel/dist/main.js
var GET_TRACER = "__netlify__getTracer";
var getTracer = (name, version) => {
  return globalThis[GET_TRACER]?.(name, version);
};
function withActiveSpan(tracer, name, optionsOrFn, contextOrFn, fn) {
  const func = typeof contextOrFn === "function" ? contextOrFn : typeof optionsOrFn === "function" ? optionsOrFn : fn;
  if (!func) {
    throw new Error("function to execute with active span is missing");
  }
  if (!tracer) {
    return func();
  }
  return tracer.withActiveSpan(name, optionsOrFn, contextOrFn, func);
}

// ../../../../../home/user/ccg-separacao/nails-and-more/node_modules/@netlify/blobs/dist/chunk-YAGWSQMB.js
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header?.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var BlobsInternalError = class extends Error {
  constructor(res) {
    let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
    if (res.headers.has(NF_REQUEST_ID)) {
      details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
    }
    super(`Netlify Blobs has generated an internal error (${details})`);
    this.name = "BlobsInternalError";
  }
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
function withSpan(span, name, fn) {
  if (span) return fn(span);
  return withActiveSpan(getTracer(), name, (span2) => {
    return fn(span2);
  });
}
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var REGION_AUTO = "auto";
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
  try {
    const res = await fetch2(url, options);
    if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch2 ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    conditions = {},
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    if ("onlyIfMatch" in conditions && conditions.onlyIfMatch) {
      headers["if-match"] = conditions.onlyIfMatch;
    } else if ("onlyIfNew" in conditions && conditions.onlyIfNew) {
      headers["if-none-match"] = "*";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    return fetchAndRetry(this.fetch, url, options);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// ../../../../../home/user/ccg-separacao/nails-and-more/node_modules/@netlify/blobs/dist/main.js
var DEPLOY_STORE_PREFIX = "deploy:";
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var SITE_STORE_PREFIX = "site:";
var STATUS_OK = 200;
var STATUS_PRE_CONDITION_FAILED = 412;
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res);
    }
  }
  async deleteAll() {
    let totalDeletedBlobs = 0;
    let hasMore = true;
    while (hasMore) {
      const res = await this.client.makeRequest({ method: "delete", storeName: this.name });
      if (res.status !== 200) {
        throw new BlobsInternalError(res);
      }
      const data = await res.json();
      if (typeof data.blobs_deleted !== "number") {
        throw new BlobsInternalError(res);
      }
      totalDeletedBlobs += data.blobs_deleted;
      hasMore = typeof data.has_more === "boolean" && data.has_more;
    }
    return {
      deletedBlobs: totalDeletedBlobs
    };
  }
  async get(key, options) {
    return withSpan(options?.span, "blobs.get", async (span) => {
      const { consistency, type } = options ?? {};
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.type": type,
        "blobs.method": "GET",
        "blobs.consistency": consistency
      });
      const res = await this.client.makeRequest({
        consistency,
        key,
        method: "get",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200) {
        throw new BlobsInternalError(res);
      }
      if (type === void 0 || type === "text") {
        return res.text();
      }
      if (type === "arrayBuffer") {
        return res.arrayBuffer();
      }
      if (type === "blob") {
        return res.blob();
      }
      if (type === "json") {
        return res.json();
      }
      if (type === "stream") {
        return res.body;
      }
      throw new BlobsInternalError(res);
    });
  }
  async getMetadata(key, options = {}) {
    return withSpan(options?.span, "blobs.getMetadata", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "HEAD",
        "blobs.consistency": options.consistency
      });
      const res = await this.client.makeRequest({
        consistency: options.consistency,
        key,
        method: "head",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const etag = res?.headers.get("etag") ?? void 0;
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag,
        metadata
      };
      return result;
    });
  }
  async getWithMetadata(key, options) {
    return withSpan(options?.span, "blobs.getWithMetadata", async (span) => {
      const { consistency, etag: requestETag, type } = options ?? {};
      const headers = requestETag ? { "if-none-match": requestETag } : void 0;
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "GET",
        "blobs.consistency": options?.consistency,
        "blobs.type": type,
        "blobs.request.etag": requestETag
      });
      const res = await this.client.makeRequest({
        consistency,
        headers,
        key,
        method: "get",
        storeName: this.name
      });
      const responseETag = res?.headers.get("etag") ?? void 0;
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.etag": responseETag,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag: responseETag,
        metadata
      };
      if (res.status === 304 && requestETag) {
        return { data: null, ...result };
      }
      if (type === void 0 || type === "text") {
        return { data: await res.text(), ...result };
      }
      if (type === "arrayBuffer") {
        return { data: await res.arrayBuffer(), ...result };
      }
      if (type === "blob") {
        return { data: await res.blob(), ...result };
      }
      if (type === "json") {
        return { data: await res.json(), ...result };
      }
      if (type === "stream") {
        return { data: res.body, ...result };
      }
      throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
    });
  }
  list(options = {}) {
    return withSpan(options.span, "blobs.list", (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.method": "GET",
        "blobs.list.paginate": options.paginate ?? false
      });
      const iterator = this.getListIterator(options);
      if (options.paginate) {
        return iterator;
      }
      return collectIterator(iterator).then(
        (items) => items.reduce(
          (acc, item) => ({
            blobs: [...acc.blobs, ...item.blobs],
            directories: [...acc.directories, ...item.directories]
          }),
          { blobs: [], directories: [] }
        )
      );
    });
  }
  async set(key, data, options = {}) {
    return withSpan(options.span, "blobs.set", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.size": typeof data == "string" ? data.length : data instanceof Blob ? data.size : data.byteLength,
        "blobs.data.type": typeof data == "string" ? "string" : data instanceof Blob ? "blob" : "arrayBuffer",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const res = await this.client.makeRequest({
        conditions,
        body: data,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
      }
      if (res.status === STATUS_OK) {
        return {
          etag,
          modified: true
        };
      }
      throw new BlobsInternalError(res);
    });
  }
  async setJSON(key, data, options = {}) {
    return withSpan(options.span, "blobs.setJSON", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.type": "json",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const payload = JSON.stringify(data);
      const headers = {
        "content-type": "application/json"
      };
      const res = await this.client.makeRequest({
        conditions,
        body: payload,
        headers,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
      }
      if (res.status === STATUS_OK) {
        return {
          etag,
          modified: true
        };
      }
      throw new BlobsInternalError(res);
    });
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static getConditions(options) {
    if ("onlyIfMatch" in options && "onlyIfNew" in options) {
      throw new Error(
        `The 'onlyIfMatch' and 'onlyIfNew' options are mutually exclusive. Using 'onlyIfMatch' will make the write succeed only if there is an entry for the key with the given content, while 'onlyIfNew' will make the write succeed only if there is no entry for the key.`
      );
    }
    if ("onlyIfMatch" in options && options.onlyIfMatch) {
      if (typeof options.onlyIfMatch !== "string") {
        throw new Error(`The 'onlyIfMatch' property expects a string representing an ETag.`);
      }
      return {
        onlyIfMatch: options.onlyIfMatch
      };
    }
    if ("onlyIfNew" in options && options.onlyIfNew) {
      if (typeof options.onlyIfNew !== "boolean") {
        throw new Error(
          `The 'onlyIfNew' property expects a boolean indicating whether the write should fail if an entry for the key already exists.`
        );
      }
      return {
        onlyIfNew: true
      };
    }
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            return withSpan(options?.span, "blobs.list.next", async (span) => {
              span?.setAttributes({
                "blobs.store": storeName,
                "blobs.method": "GET",
                "blobs.list.paginate": options?.paginate ?? false,
                "blobs.list.done": done,
                "blobs.list.cursor": currentCursor ?? void 0
              });
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters,
                storeName
              });
              span?.setAttributes({
                "blobs.response.status": res.status
              });
              let blobs = [];
              let directories = [];
              if (![200, 204, 404].includes(res.status)) {
                throw new BlobsInternalError(res);
              }
              if (res.status === 404) {
                done = true;
              } else {
                const page = await res.json();
                if (page.next_cursor) {
                  currentCursor = page.next_cursor;
                } else {
                  done = true;
                }
                blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                directories = page.directories ?? [];
              }
              return {
                done: false,
                value: {
                  blobs,
                  directories
                }
              };
            });
          }
        };
      }
    };
  }
};
var getDeployStore = (input = {}, options) => {
  const context = getEnvironmentContext();
  const mergedOptions = typeof input === "string" ? { ...options, name: input } : input;
  const deployID = mergedOptions.deployID ?? context.deployID;
  if (!deployID) {
    throw new MissingBlobsEnvironmentError(["deployID"]);
  }
  const clientOptions = getClientOptions(mergedOptions, context);
  if (!clientOptions.region) {
    if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
      if (!context.primaryRegion) {
        throw new Error(
          "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the `getDeployStore` options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
        );
      }
      clientOptions.region = context.primaryRegion;
    } else {
      clientOptions.region = REGION_AUTO;
    }
  }
  const client = new Client(clientOptions);
  return new Store({ client, deployID, name: mergedOptions.name });
};
var getStore = (input, options) => {
  if (typeof input === "string") {
    const contextOverride = options?.siteID && options?.token ? { siteID: options?.siteID, token: options?.token } : void 0;
    const clientOptions = getClientOptions(options ?? {}, contextOverride);
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const contextOverride = input?.siteID && input?.token ? { siteID: input?.siteID, token: input?.token } : void 0;
    const clientOptions = getClientOptions(input, contextOverride);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const clientOptions = getClientOptions(input);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// ../../../../../home/user/ccg-separacao/nails-and-more/netlify/functions/api.mjs
var UNIDADES = ["Shopping Tijuca", "NorteShopping", "Shopping Metropolitano", "Shopping Via Parque"];
var QUANDO = ["na_hora", "antecipado"];
var FORMAS = ["pix", "credito", "debito", "dinheiro"];
var STATUS = ["pendente", "confirmado", "concluido", "cancelado"];
var VAGAS_SEM_EQUIPE = 3;
var SELOS_META = 10;
function abrirStore() {
  if (Netlify.context?.deploy.context === "production") {
    return getStore({ name: "agendamentos", consistency: "strong" });
  }
  return getDeployStore({ name: "agendamentos", consistency: "strong" });
}
var json = (corpo, status = 200) => new Response(JSON.stringify(corpo), { status, headers: { "content-type": "application/json; charset=utf-8" } });
function pinOk(req) {
  const pin = Netlify.env.get("ADMIN_PIN") || "2016";
  return req.headers.get("x-pin") === pin;
}
var digitos = (s) => String(s || "").replace(/\D/g, "");
async function listarAgendamentos(store) {
  const { blobs } = await store.list({ prefix: "ag-" });
  const itens = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
  return itens.filter(Boolean);
}
var lerEquipe = async (store) => await store.get("config-equipe", { type: "json" }) || [];
var lerBloqueios = async (store) => await store.get("config-bloqueios", { type: "json" }) || [];
function hojeISO() {
  const agora = new Date(Date.now() - 3 * 60 * 60 * 1e3);
  return agora.toISOString().slice(0, 10);
}
function gerarHorarios(dataISO) {
  const [a, m, d] = dataISO.split("-").map(Number);
  const diaSemana = new Date(Date.UTC(a, m - 1, d)).getUTCDay();
  const inicio = diaSemana === 0 ? 13 * 60 : 10 * 60;
  const fim = diaSemana === 0 ? 21 * 60 : 22 * 60;
  const horarios = [];
  for (let min = inicio; min <= fim - 30; min += 30) {
    horarios.push(`${String(Math.floor(min / 60)).padStart(2, "0")}:${String(min % 60).padStart(2, "0")}`);
  }
  return horarios;
}
var minutosDe = (hora) => {
  const [h, m] = hora.split(":").map(Number);
  return h * 60 + m;
};
var normalizarDuracao = (dur) => {
  const n = Number(dur);
  if (!Number.isFinite(n)) return 30;
  return Math.min(480, Math.max(30, Math.ceil(n / 30) * 30));
};
var intervaloDe = (ag) => {
  const ini = minutosDe(ag.hora);
  return [ini, ini + normalizarDuracao(ag.duracao || 30)];
};
var sobrepoe = (aIni, aFim, bIni, bFim) => aIni < bFim && bIni < aFim;
function bloqueiaProfissional(bloqueios, unidade, data, ini, fim, profissionalId) {
  return bloqueios.some((bl) => {
    if (bl.unidade !== unidade || bl.data !== data) return false;
    if (bl.profissionalId && bl.profissionalId !== profissionalId) return false;
    return sobrepoe(ini, fim, minutosDe(bl.inicio), minutosDe(bl.fim));
  });
}
function horasLivres({ data, unidade, dur, profissionalId, ags, equipe, bloqueios }) {
  const grade = gerarHorarios(data);
  const duracao = normalizarDuracao(dur);
  const fechamento = minutosDe(grade[grade.length - 1]) + 30;
  const doDia = ags.filter((ag) => ag.data === data && ag.unidade === unidade && ag.status !== "cancelado");
  const profs = equipe.filter((p) => p.ativo !== false && (p.unidades || []).includes(unidade));
  const livres = [];
  for (const hora of grade) {
    const ini = minutosDe(hora);
    const fim = ini + duracao;
    if (fim > fechamento) continue;
    if (profs.length > 0) {
      const candidatos = profissionalId ? profs.filter((p) => p.id === profissionalId) : profs;
      const alguemLivre = candidatos.some((p) => {
        if (bloqueiaProfissional(bloqueios, unidade, data, ini, fim, p.id)) return false;
        return !doDia.some((ag) => {
          if (ag.profissionalId !== p.id) return false;
          const [aIni, aFim] = intervaloDe(ag);
          return sobrepoe(ini, fim, aIni, aFim);
        });
      });
      if (alguemLivre) livres.push(hora);
    } else {
      if (bloqueiaProfissional(bloqueios, unidade, data, ini, fim, null)) continue;
      let cabe = true;
      for (let b = ini; b < fim; b += 30) {
        const ocupadas = doDia.filter((ag) => {
          const [aIni, aFim] = intervaloDe(ag);
          return sobrepoe(b, b + 30, aIni, aFim);
        }).length;
        if (ocupadas >= VAGAS_SEM_EQUIPE) {
          cabe = false;
          break;
        }
      }
      if (cabe) livres.push(hora);
    }
  }
  return livres;
}
function escolherProfissional({ data, unidade, hora, dur, profissionalId, ags, equipe, bloqueios }) {
  const profs = equipe.filter((p) => p.ativo !== false && (p.unidades || []).includes(unidade));
  if (profs.length === 0) return { id: null, nome: null };
  const ini = minutosDe(hora);
  const fim = ini + normalizarDuracao(dur);
  const doDia = ags.filter((ag) => ag.data === data && ag.unidade === unidade && ag.status !== "cancelado");
  const livres = (profissionalId ? profs.filter((p) => p.id === profissionalId) : profs).filter((p) => {
    if (bloqueiaProfissional(bloqueios, unidade, data, ini, fim, p.id)) return false;
    return !doDia.some((ag) => {
      if (ag.profissionalId !== p.id) return false;
      const [aIni, aFim] = intervaloDe(ag);
      return sobrepoe(ini, fim, aIni, aFim);
    });
  });
  if (livres.length === 0) return null;
  livres.sort((a, b) => {
    const carga = (p) => doDia.filter((ag) => ag.profissionalId === p.id).reduce((s, ag) => s + normalizarDuracao(ag.duracao || 30), 0);
    return carga(a) - carga(b);
  });
  return { id: livres[0].id, nome: livres[0].nome };
}
function calcularFidelidade(ags, telefone) {
  const tel = digitos(telefone);
  const concluidos = ags.filter((ag) => digitos(ag.telefone) === tel && ag.status === "concluido").length;
  return {
    concluidos,
    selos: concluidos % SELOS_META,
    faltam: SELOS_META - concluidos % SELOS_META,
    meta: SELOS_META,
    temBrinde: concluidos > 0 && concluidos % SELOS_META === 0
  };
}
function validarAgendamento(b) {
  if (!b || typeof b !== "object") return "Dados inv\xE1lidos.";
  if (typeof b.nome !== "string" || b.nome.trim().length < 3) return "Digite o nome completo.";
  if (typeof b.telefone !== "string" || digitos(b.telefone).length < 10) return "Telefone inv\xE1lido.";
  if (!UNIDADES.includes(b.unidade)) return "Unidade inv\xE1lida.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.data || "")) return "Data inv\xE1lida.";
  if (b.data < hojeISO()) return "Essa data j\xE1 passou.";
  if (!/^\d{2}:\d{2}$/.test(b.hora || "")) return "Hor\xE1rio inv\xE1lido.";
  if (!Array.isArray(b.servicos) || b.servicos.length === 0) return "Escolha pelo menos um servi\xE7o.";
  for (const s of b.servicos) {
    if (typeof s?.nome !== "string" || typeof s?.preco !== "number" || s.preco < 0) return "Servi\xE7o inv\xE1lido.";
  }
  if (!QUANDO.includes(b.pagamento?.quando)) return "Momento de pagamento inv\xE1lido.";
  if (!FORMAS.includes(b.pagamento?.forma)) return "Forma de pagamento inv\xE1lida.";
  if (b.pagamento.quando === "antecipado" && b.pagamento.forma === "dinheiro") {
    return "Pagamento antecipado n\xE3o aceita dinheiro.";
  }
  return null;
}
async function criarPagamentoPix(ag) {
  const token = Netlify.env.get("MP_ACCESS_TOKEN");
  if (!token) return null;
  try {
    const r = await fetch("https://api.mercadopago.com/v1/payments", {
      method: "POST",
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json",
        "x-idempotency-key": ag.id
      },
      body: JSON.stringify({
        transaction_amount: ag.total,
        description: `Nails & More Salon \u2014 ${ag.data} ${ag.hora} (${ag.nome})`,
        payment_method_id: "pix",
        external_reference: ag.id,
        payer: { email: `${digitos(ag.telefone)}@clientes.nailsandmore.app` }
      })
    });
    if (!r.ok) {
      console.log("MercadoPago recusou o pagamento:", r.status, await r.text());
      return null;
    }
    const pg = await r.json();
    const dados = pg.point_of_interaction?.transaction_data;
    if (!dados?.qr_code) return null;
    return {
      mpPaymentId: pg.id,
      copiaECola: dados.qr_code,
      qrCodeBase64: dados.qr_code_base64 || null
    };
  } catch (e) {
    console.log("Erro ao criar Pix no Mercado Pago:", e.message);
    return null;
  }
}
async function processarWebhookMercadoPago(req, store) {
  const token = Netlify.env.get("MP_ACCESS_TOKEN");
  if (!token) return json({ ok: true });
  let corpo;
  try {
    corpo = await req.json();
  } catch {
    return json({ ok: true });
  }
  const pagamentoId = corpo?.data?.id;
  if (!pagamentoId || corpo?.type !== "payment") return json({ ok: true });
  const r = await fetch(`https://api.mercadopago.com/v1/payments/${pagamentoId}`, {
    headers: { authorization: `Bearer ${token}` }
  });
  if (!r.ok) return json({ ok: true });
  const pg = await r.json();
  if (pg.status === "approved" && pg.external_reference?.startsWith("ag-")) {
    const ag = await store.get(pg.external_reference, { type: "json" });
    if (ag) {
      ag.pagamento.status = "pago";
      await store.setJSON(ag.id, ag);
    }
  }
  return json({ ok: true });
}
var api_default = async (req) => {
  const url = new URL(req.url);
  const rota = url.pathname.replace(/\/+$/, "");
  const store = abrirStore();
  if (rota === "/api/ping") return json({ ok: true, versao: 2, pixOnline: !!Netlify.env.get("MP_ACCESS_TOKEN") });
  if (rota === "/api/webhooks/mercadopago" && req.method === "POST") {
    return processarWebhookMercadoPago(req, store);
  }
  if (rota === "/api/contexto" && req.method === "GET") {
    const unidade = url.searchParams.get("unidade") || "";
    const equipe = await lerEquipe(store);
    const daUnidade = equipe.filter((p) => p.ativo !== false && (p.unidades || []).includes(unidade)).map((p) => ({ id: p.id, nome: p.nome, categorias: p.categorias || [] }));
    return json({ equipe: daUnidade });
  }
  if (rota === "/api/disponibilidade" && req.method === "GET") {
    const data = url.searchParams.get("data") || "";
    const unidade = url.searchParams.get("unidade") || "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !UNIDADES.includes(unidade)) {
      return json({ erro: "Par\xE2metros inv\xE1lidos." }, 400);
    }
    const [ags, equipe, bloqueios] = await Promise.all([
      listarAgendamentos(store),
      lerEquipe(store),
      lerBloqueios(store)
    ]);
    const livres = horasLivres({
      data,
      unidade,
      dur: url.searchParams.get("dur") || 30,
      profissionalId: url.searchParams.get("profissional") || null,
      ags,
      equipe,
      bloqueios
    });
    return json({ horasLivres: livres });
  }
  if (rota === "/api/agendamentos" && req.method === "POST") {
    let corpo;
    try {
      corpo = await req.json();
    } catch {
      return json({ erro: "Corpo inv\xE1lido." }, 400);
    }
    const erro = validarAgendamento(corpo);
    if (erro) return json({ erro }, 400);
    const [ags, equipe, bloqueios] = await Promise.all([
      listarAgendamentos(store),
      lerEquipe(store),
      lerBloqueios(store)
    ]);
    const duracao = normalizarDuracao(corpo.duracao);
    const livres = horasLivres({
      data: corpo.data,
      unidade: corpo.unidade,
      dur: duracao,
      profissionalId: corpo.profissionalId || null,
      ags,
      equipe,
      bloqueios
    });
    if (!livres.includes(corpo.hora)) {
      return json({ erro: "Esse hor\xE1rio acabou de ficar indispon\xEDvel \u2014 escolha outro, por favor." }, 409);
    }
    const prof = escolherProfissional({
      data: corpo.data,
      unidade: corpo.unidade,
      hora: corpo.hora,
      dur: duracao,
      profissionalId: corpo.profissionalId || null,
      ags,
      equipe,
      bloqueios
    });
    if (prof === null) {
      return json({ erro: "Esse hor\xE1rio acabou de ficar indispon\xEDvel \u2014 escolha outro, por favor." }, 409);
    }
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const agendamento = {
      id: `ag-${id}`,
      criadoEm: (/* @__PURE__ */ new Date()).toISOString(),
      nome: corpo.nome.trim().slice(0, 120),
      telefone: corpo.telefone.slice(0, 20),
      unidade: corpo.unidade,
      data: corpo.data,
      hora: corpo.hora,
      duracao,
      profissionalId: prof.id,
      profissional: prof.nome,
      servicos: corpo.servicos.map((s) => ({
        nome: String(s.nome).slice(0, 120),
        preco: s.preco,
        aPartirDe: !!s.aPartirDe,
        combo: !!s.combo
      })),
      total: corpo.servicos.reduce((soma, s) => soma + s.preco, 0),
      obs: String(corpo.obs || "").slice(0, 500),
      pagamento: { quando: corpo.pagamento.quando, forma: corpo.pagamento.forma, status: "pendente" },
      status: "pendente",
      lembreteEnviado: false
    };
    let pix = null;
    if (agendamento.pagamento.quando === "antecipado" && agendamento.pagamento.forma === "pix") {
      pix = await criarPagamentoPix(agendamento);
      if (pix) agendamento.pagamento.mpPaymentId = pix.mpPaymentId;
    }
    await store.setJSON(agendamento.id, agendamento);
    return json({
      agendamento,
      fidelidade: calcularFidelidade(ags, agendamento.telefone),
      pix: pix ? { copiaECola: pix.copiaECola, qrCodeBase64: pix.qrCodeBase64 } : null
    }, 201);
  }
  if (!pinOk(req)) return json({ erro: "PIN incorreto." }, 401);
  if (rota === "/api/agendamentos" && req.method === "GET") {
    const todos = await listarAgendamentos(store);
    todos.sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora) || a.criadoEm.localeCompare(b.criadoEm));
    const fidelidade = {};
    for (const ag of todos) {
      const tel = digitos(ag.telefone);
      if (!fidelidade[tel]) fidelidade[tel] = calcularFidelidade(todos, ag.telefone);
    }
    return json({ agendamentos: todos, fidelidade });
  }
  const patch = rota.match(/^\/api\/agendamentos\/(ag-[\w-]+)$/);
  if (patch && req.method === "PATCH") {
    let corpo;
    try {
      corpo = await req.json();
    } catch {
      return json({ erro: "Corpo inv\xE1lido." }, 400);
    }
    const ag = await store.get(patch[1], { type: "json" });
    if (!ag) return json({ erro: "Agendamento n\xE3o encontrado." }, 404);
    if (corpo.status !== void 0) {
      if (!STATUS.includes(corpo.status)) return json({ erro: "Status inv\xE1lido." }, 400);
      ag.status = corpo.status;
    }
    if (corpo.pagamentoStatus !== void 0) {
      if (!["pendente", "pago"].includes(corpo.pagamentoStatus)) return json({ erro: "Pagamento inv\xE1lido." }, 400);
      ag.pagamento.status = corpo.pagamentoStatus;
    }
    await store.setJSON(ag.id, ag);
    return json({ agendamento: ag });
  }
  if (rota === "/api/equipe") {
    if (req.method === "GET") return json({ equipe: await lerEquipe(store) });
    if (req.method === "PUT") {
      let corpo;
      try {
        corpo = await req.json();
      } catch {
        return json({ erro: "Corpo inv\xE1lido." }, 400);
      }
      if (!Array.isArray(corpo.equipe)) return json({ erro: "Formato inv\xE1lido." }, 400);
      const equipe = corpo.equipe.slice(0, 60).map((p) => ({
        id: String(p.id || `pr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`),
        nome: String(p.nome || "").slice(0, 80),
        unidades: (Array.isArray(p.unidades) ? p.unidades : []).filter((u) => UNIDADES.includes(u)),
        categorias: (Array.isArray(p.categorias) ? p.categorias : []).map(String),
        ativo: p.ativo !== false
      })).filter((p) => p.nome.trim().length > 0);
      await store.setJSON("config-equipe", equipe);
      return json({ equipe });
    }
  }
  if (rota === "/api/bloqueios") {
    if (req.method === "GET") return json({ bloqueios: await lerBloqueios(store) });
    if (req.method === "PUT") {
      let corpo;
      try {
        corpo = await req.json();
      } catch {
        return json({ erro: "Corpo inv\xE1lido." }, 400);
      }
      if (!Array.isArray(corpo.bloqueios)) return json({ erro: "Formato inv\xE1lido." }, 400);
      const bloqueios = corpo.bloqueios.slice(0, 300).map((bl) => ({
        id: String(bl.id || `bl-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`),
        unidade: bl.unidade,
        data: bl.data,
        inicio: bl.inicio,
        fim: bl.fim,
        profissionalId: bl.profissionalId || null,
        motivo: String(bl.motivo || "").slice(0, 120)
      })).filter(
        (bl) => UNIDADES.includes(bl.unidade) && /^\d{4}-\d{2}-\d{2}$/.test(bl.data || "") && /^\d{2}:\d{2}$/.test(bl.inicio || "") && /^\d{2}:\d{2}$/.test(bl.fim || "") && minutosDe(bl.inicio) < minutosDe(bl.fim)
      );
      await store.setJSON("config-bloqueios", bloqueios);
      return json({ bloqueios });
    }
  }
  return json({ erro: "Rota n\xE3o encontrada." }, 404);
};
var config = {
  path: [
    "/api/ping",
    "/api/contexto",
    "/api/disponibilidade",
    "/api/agendamentos",
    "/api/agendamentos/*",
    "/api/equipe",
    "/api/bloqueios",
    "/api/webhooks/mercadopago"
  ]
};
export {
  calcularFidelidade,
  config,
  api_default as default,
  escolherProfissional,
  gerarHorarios,
  horasLivres,
  normalizarDuracao,
  validarAgendamento
};
